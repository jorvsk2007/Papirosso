import {
    obtenerProductos,
    crearProducto,
    actualizarProducto,
    eliminarProducto,
    obtenerVentas
} from './supabaseClient.js';

// ─── VERIFICAR SESIÓN ADMIN ──────────────────────────────────────
const sesion = JSON.parse(sessionStorage.getItem('trabajador') || 'null');
if (!sesion || sesion.rol !== 'Admin') {
    alert('Acceso denegado. Solo administradores.');
    window.location.href = 'login.html';
}

// ─── ESTADO ──────────────────────────────────────────────────────
let productos = [];
let vistaActual = 'inventario';
let productoEditando = null;

// ─── INIT ────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
    document.getElementById('admin-nombre').textContent =
        `${sesion.nombre} ${sesion.apellidos || ''}`.trim();

    bindNav();
    bindModal();
    cargarInventario();
});

// ─── NAVEGACIÓN ──────────────────────────────────────────────────
function bindNav() {
    document.querySelectorAll('.nav-tab').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.nav-tab').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            vistaActual = btn.dataset.vista;
            if (vistaActual === 'inventario') cargarInventario();
            if (vistaActual === 'ventas') cargarVentas();
        });
    });

    document.getElementById('btn-logout').addEventListener('click', () => {
        sessionStorage.removeItem('trabajador');
        window.location.href = 'login.html';
    });
}

// ─── INVENTARIO ──────────────────────────────────────────────────
async function cargarInventario() {
    const content = document.getElementById('main-content');
    content.innerHTML = '<div class="loading-msg">Cargando inventario...</div>';

    const { data, error } = await obtenerProductos();
    if (error) {
        content.innerHTML = `<div class="error-msg">Error al cargar: ${error.message}</div>`;
        return;
    }

    productos = data || [];
    renderInventario(productos);
}

function renderInventario(lista) {
    const content = document.getElementById('main-content');

    const totalProductos = lista.length;
    const stockTotal = lista.reduce((s, p) => s + p.cant_exist, 0);
    const agotados = lista.filter(p => p.cant_exist === 0).length;
    const stockBajo = lista.filter(p => p.cant_exist > 0 && p.cant_exist <= 5).length;

    content.innerHTML = `
        <div class="inv-header">
            <div>
                <h2 class="section-title">Control de Inventario</h2>
                <p class="section-sub">Gestiona existencias, precios y productos del catálogo.</p>
            </div>
            <button class="btn-primary" id="btn-nuevo-producto">+ Nuevo Producto</button>
        </div>

        <div class="stats-row">
            <div class="stat-card">
                <span class="stat-num">${totalProductos}</span>
                <span class="stat-label">Productos</span>
            </div>
            <div class="stat-card">
                <span class="stat-num">${stockTotal}</span>
                <span class="stat-label">Unidades totales</span>
            </div>
            <div class="stat-card warn">
                <span class="stat-num">${stockBajo}</span>
                <span class="stat-label">Stock bajo (≤5)</span>
            </div>
            <div class="stat-card danger">
                <span class="stat-num">${agotados}</span>
                <span class="stat-label">Agotados</span>
            </div>
        </div>

        <div class="table-wrapper">
            <div class="table-toolbar">
                <input id="inv-search" type="search" placeholder="Buscar por nombre o ID..." class="search-input">
            </div>
            <table class="inv-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Precio</th>
                        <th>Stock</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="inv-tbody">
                    ${renderFilas(lista)}
                </tbody>
            </table>
        </div>
    `;

    document.getElementById('btn-nuevo-producto').addEventListener('click', abrirModalNuevo);
    document.getElementById('inv-search').addEventListener('input', e => {
        const t = e.target.value.toLowerCase();
        const filtrado = productos.filter(p =>
            p.nombre.toLowerCase().includes(t) || p.id_producto.toLowerCase().includes(t)
        );
        document.getElementById('inv-tbody').innerHTML = renderFilas(filtrado);
        bindAcciones();
    });

    bindAcciones();
}

function renderFilas(lista) {
    if (lista.length === 0) return '<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted);">Sin resultados.</td></tr>';

    return lista.map(p => {
        let estadoClass = 'badge-ok';
        let estadoText = 'Normal';
        if (p.cant_exist === 0) { estadoClass = 'badge-danger'; estadoText = 'Agotado'; }
        else if (p.cant_exist <= 5) { estadoClass = 'badge-warn'; estadoText = 'Stock bajo'; }

        return `
        <tr data-id="${p.id_producto}">
            <td><code>${p.id_producto}</code></td>
            <td><strong>${p.nombre}</strong></td>
            <td class="desc-cell">${p.descripcion || '—'}</td>
            <td>$${Number(p.precio).toFixed(2)}</td>
            <td>
                <div class="stock-control">
                    <button class="btn-stock-adj" data-id="${p.id_producto}" data-delta="-1">−</button>
                    <span class="stock-num ${p.cant_exist === 0 ? 'text-danger' : p.cant_exist <= 5 ? 'text-warn' : ''}">${p.cant_exist}</span>
                    <button class="btn-stock-adj" data-id="${p.id_producto}" data-delta="1">+</button>
                </div>
            </td>
            <td><span class="badge ${estadoClass}">${estadoText}</span></td>
            <td>
                <div class="action-btns">
                    <button class="btn-edit" data-id="${p.id_producto}">✏️ Editar</button>
                    <button class="btn-delete" data-id="${p.id_producto}">🗑️ Eliminar</button>
                </div>
            </td>
        </tr>`;
    }).join('');
}

function bindAcciones() {
    document.querySelectorAll('.btn-edit').forEach(btn => {
        btn.addEventListener('click', () => abrirModalEditar(btn.dataset.id));
    });
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', () => confirmarEliminar(btn.dataset.id));
    });
    document.querySelectorAll('.btn-stock-adj').forEach(btn => {
        btn.addEventListener('click', () => ajustarStockRapido(btn.dataset.id, parseInt(btn.dataset.delta)));
    });
}

async function ajustarStockRapido(id, delta) {
    const producto = productos.find(p => p.id_producto === id);
    if (!producto) return;

    const nuevoStock = producto.cant_exist + delta;
    if (nuevoStock < 0) { mostrarToast('El stock no puede ser negativo.', 'warn'); return; }

    const { error } = await actualizarProducto(id, { cant_exist: nuevoStock });
    if (error) { mostrarToast('Error: ' + error.message, 'error'); return; }

    producto.cant_exist = nuevoStock;

    // Actualizar solo la celda de stock visualmente
    const fila = document.querySelector(`tr[data-id="${id}"]`);
    if (fila) {
        const num = fila.querySelector('.stock-num');
        const badge = fila.querySelector('.badge');
        if (num) {
            num.textContent = nuevoStock;
            num.className = 'stock-num ' + (nuevoStock === 0 ? 'text-danger' : nuevoStock <= 5 ? 'text-warn' : '');
        }
        if (badge) {
            if (nuevoStock === 0) { badge.className = 'badge badge-danger'; badge.textContent = 'Agotado'; }
            else if (nuevoStock <= 5) { badge.className = 'badge badge-warn'; badge.textContent = 'Stock bajo'; }
            else { badge.className = 'badge badge-ok'; badge.textContent = 'Normal'; }
        }
    }
    mostrarToast(`Stock de "${producto.nombre}" actualizado a ${nuevoStock}`, 'ok');
}

// ─── MODAL PRODUCTO ──────────────────────────────────────────────
function bindModal() {
    document.getElementById('modal-overlay').addEventListener('click', e => {
        if (e.target.id === 'modal-overlay') cerrarModal();
    });
    document.getElementById('btn-modal-cancel').addEventListener('click', cerrarModal);
    document.getElementById('form-producto').addEventListener('submit', guardarProducto);
}

function abrirModalNuevo() {
    productoEditando = null;
    document.getElementById('modal-title').textContent = 'Nuevo Producto';
    document.getElementById('form-id').value = '';
    document.getElementById('form-nombre').value = '';
    document.getElementById('form-descripcion').value = '';
    document.getElementById('form-precio').value = '';
    document.getElementById('form-stock').value = '';
    document.getElementById('field-id').style.display = 'block';
    abrirModal();
}

function abrirModalEditar(id) {
    const p = productos.find(x => x.id_producto === id);
    if (!p) return;
    productoEditando = p;

    document.getElementById('modal-title').textContent = 'Editar Producto';
    document.getElementById('form-id').value = p.id_producto;
    document.getElementById('form-nombre').value = p.nombre;
    document.getElementById('form-descripcion').value = p.descripcion || '';
    document.getElementById('form-precio').value = p.precio;
    document.getElementById('form-stock').value = p.cant_exist;
    document.getElementById('field-id').style.display = 'none'; // No editar ID
    abrirModal();
}

function abrirModal() {
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('form-nombre').focus();
}

function cerrarModal() {
    document.getElementById('modal-overlay').classList.add('hidden');
}

async function guardarProducto(e) {
    e.preventDefault();
    const btnGuardar = document.getElementById('btn-modal-save');
    btnGuardar.disabled = true;
    btnGuardar.textContent = 'Guardando...';

    const nombre = document.getElementById('form-nombre').value.trim();
    const descripcion = document.getElementById('form-descripcion').value.trim();
    const precio = parseFloat(document.getElementById('form-precio').value);
    const cant_exist = parseInt(document.getElementById('form-stock').value);

    if (!nombre || isNaN(precio) || precio <= 0 || isNaN(cant_exist) || cant_exist < 0) {
        mostrarToast('Revisa los campos: nombre, precio (>0) y stock (≥0) son obligatorios.', 'warn');
        btnGuardar.disabled = false;
        btnGuardar.textContent = 'Guardar';
        return;
    }

    if (productoEditando) {
        const { error } = await actualizarProducto(productoEditando.id_producto, { nombre, descripcion, precio, cant_exist });
        if (error) { mostrarToast('Error al actualizar: ' + error.message, 'error'); }
        else { mostrarToast('Producto actualizado.', 'ok'); cerrarModal(); await cargarInventario(); }
    } else {
        const id = document.getElementById('form-id').value.trim();
        if (!id) { mostrarToast('El ID del producto es obligatorio.', 'warn'); btnGuardar.disabled = false; btnGuardar.textContent = 'Guardar'; return; }
        const { error } = await crearProducto({ id_producto: id, nombre, descripcion, precio, cant_exist });
        if (error) { mostrarToast('Error al crear: ' + error.message, 'error'); }
        else { mostrarToast('Producto creado exitosamente.', 'ok'); cerrarModal(); await cargarInventario(); }
    }

    btnGuardar.disabled = false;
    btnGuardar.textContent = 'Guardar';
}

async function confirmarEliminar(id) {
    const p = productos.find(x => x.id_producto === id);
    if (!p) return;
    if (!confirm(`¿Seguro que deseas eliminar "${p.nombre}"?\nEsta acción no se puede deshacer.`)) return;

    const { error } = await eliminarProducto(id);
    if (error) mostrarToast('Error al eliminar: ' + error.message, 'error');
    else { mostrarToast(`"${p.nombre}" eliminado.`, 'ok'); await cargarInventario(); }
}

// ─── VENTAS ──────────────────────────────────────────────────────
async function cargarVentas() {
    const content = document.getElementById('main-content');
    content.innerHTML = '<div class="loading-msg">Cargando ventas...</div>';

    const { data, error } = await obtenerVentas();
    if (error) { content.innerHTML = `<div class="error-msg">Error: ${error.message}</div>`; return; }

    const ventas = data || [];
    const totalVentas = ventas.reduce((s, v) => s + Number(v.precio_total), 0);

    content.innerHTML = `
        <div class="inv-header">
            <div>
                <h2 class="section-title">Historial de Ventas</h2>
                <p class="section-sub">${ventas.length} ventas registradas · Total acumulado: <strong>$${totalVentas.toFixed(2)}</strong></p>
            </div>
        </div>
        <div class="table-wrapper">
            <table class="inv-table">
                <thead>
                    <tr>
                        <th>ID Venta</th>
                        <th>Fecha</th>
                        <th>Total</th>
                        <th>Trabajador (CURP)</th>
                        <th>Cliente (CURP)</th>
                    </tr>
                </thead>
                <tbody>
                    ${ventas.length === 0 ? '<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--text-muted);">Sin ventas registradas.</td></tr>' :
                    ventas.map(v => `
                        <tr>
                            <td><code>${v.id_venta}</code></td>
                            <td>${new Date(v.fecha).toLocaleString('es-MX')}</td>
                            <td><strong>$${Number(v.precio_total).toFixed(2)}</strong></td>
                            <td><small>${v.curp_trabajador}</small></td>
                            <td><small>${v.curp_cliente || 'Público'}</small></td>
                        </tr>`).join('')}
                </tbody>
            </table>
        </div>
    `;
}

// ─── TOAST ───────────────────────────────────────────────────────
function mostrarToast(mensaje, tipo = 'ok') {
    let toast = document.getElementById('toast-admin');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast-admin';
        document.body.appendChild(toast);
    }
    toast.textContent = mensaje;
    toast.className = `toast toast-${tipo} show`;
    setTimeout(() => toast.classList.remove('show'), 3500);
}
