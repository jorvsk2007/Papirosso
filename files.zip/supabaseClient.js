import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/supabase.mjs';

const supabaseUrl = window.SUPABASE_URL || '';
const supabaseKey = window.SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseKey);

// ─── AUTENTICACIÓN ───────────────────────────────────────────────
export async function getTrabajadorPorCURP(curp) {
    // Join trabajadores → persona para obtener nombre
    return await supabase
        .from('trabajadores')
        .select('curp, password, rol, persona(nombre, apellidos, correo)')
        .eq('curp', curp)
        .single();
}

// ─── PRODUCTOS ───────────────────────────────────────────────────
export async function obtenerProductos() {
    return await supabase
        .from('producto')
        .select('id_producto, nombre, descripcion, precio, cant_exist')
        .order('nombre', { ascending: true });
}

export async function obtenerProductoPorId(idProducto) {
    return await supabase
        .from('producto')
        .select('id_producto, nombre, descripcion, precio, cant_exist')
        .eq('id_producto', idProducto)
        .single();
}

export async function crearProducto(producto) {
    return await supabase
        .from('producto')
        .insert([producto]);
}

export async function actualizarProducto(idProducto, campos) {
    return await supabase
        .from('producto')
        .update(campos)
        .eq('id_producto', idProducto);
}

export async function eliminarProducto(idProducto) {
    return await supabase
        .from('producto')
        .delete()
        .eq('id_producto', idProducto);
}

// ─── STOCK (con validación server-side) ──────────────────────────
/**
 * Descuenta stock SOLO si hay suficiente existencia.
 * Retorna { ok: true } o { ok: false, disponible: N }
 */
export async function descontarStock(idProducto, cantidad) {
    // Leer stock actual
    const { data, error } = await obtenerProductoPorId(idProducto);
    if (error || !data) return { ok: false, error: error?.message || 'Producto no encontrado' };

    if (data.cant_exist < cantidad) {
        return { ok: false, disponible: data.cant_exist };
    }

    const { error: updateError } = await supabase
        .from('producto')
        .update({ cant_exist: data.cant_exist - cantidad })
        .eq('id_producto', idProducto);

    if (updateError) return { ok: false, error: updateError.message };
    return { ok: true };
}

// ─── VENTAS ──────────────────────────────────────────────────────
export async function registrarVenta(ventaData) {
    return await supabase
        .from('ventas')
        .insert([ventaData])
        .select()
        .single();
}

export async function registrarDetallesVenta(detalles) {
    return await supabase
        .from('detalle_venta')
        .insert(detalles);
}

export async function obtenerVentas() {
    return await supabase
        .from('ventas')
        .select('id_venta, fecha, precio_total, curp_cliente, curp_trabajador')
        .order('fecha', { ascending: false });
}

// ─── TRABAJADORES (para reportes admin) ──────────────────────────
export async function obtenerTrabajadores() {
    return await supabase
        .from('trabajadores')
        .select('curp, rol, sueldo, persona(nombre, apellidos, correo, telefono)');
}
