import { getTrabajadorPorCURP } from './supabaseClient.js';

const form = document.getElementById('login-form');
const curpInput = document.getElementById('login-curp');
const passwordInput = document.getElementById('login-password');
const errorMessage = document.getElementById('login-error');

function mostrarError(text) {
    if (!errorMessage) return;
    errorMessage.textContent = text;
    errorMessage.classList.remove('hidden');
}

function cerrarError() {
    if (!errorMessage) return;
    errorMessage.textContent = '';
    errorMessage.classList.add('hidden');
}

async function ejecutarLogin(event) {
    event.preventDefault();
    cerrarError();

    const curp = curpInput.value.trim().toUpperCase();
    const password = passwordInput.value.trim();

    if (curp.length < 4) {
        mostrarError('Ingresa una CURP válida de al menos 4 caracteres.');
        return;
    }
    if (password.length < 4) {
        mostrarError('La contraseña debe tener al menos 4 caracteres.');
        return;
    }

    const btnSubmit = form.querySelector('button[type="submit"]');
    btnSubmit.disabled = true;
    btnSubmit.textContent = 'Verificando...';

    try {
        const { data, error } = await getTrabajadorPorCURP(curp);

        if (error || !data) {
            mostrarError('CURP no encontrada. Verifica tu cuenta.');
            return;
        }

        if (data.password !== password) {
            mostrarError('Contraseña incorrecta.');
            return;
        }

        // Guardar sesión
        const sesion = {
            curp: data.curp,
            rol: data.rol,
            nombre: data.persona?.nombre || 'Trabajador',
            apellidos: data.persona?.apellidos || '',
        };
        sessionStorage.setItem('trabajador', JSON.stringify(sesion));

        // Redirigir según rol
        const rol = data.rol.toLowerCase();
        if (rol === 'admin') {
            window.location.href = 'admin.html';
        } else {
            window.location.href = 'cliente-publico.html';
        }

    } catch (err) {
        mostrarError('Error de conexión. Revisa tu red o Supabase.');
        console.error(err);
    } finally {
        btnSubmit.disabled = false;
        btnSubmit.textContent = 'Iniciar Sesión';
    }
}

if (form) {
    form.addEventListener('submit', ejecutarLogin);
}
