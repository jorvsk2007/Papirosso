import { obtenerProductos, descontarStock, registrarVenta, registrarDetallesVenta } from './supabaseClient.js';

const searchInput = document.getElementById('public-search');
const gridContainer = document.getElementById('product-grid');
const cartItemsContainer = document.getElementById('cart-items');
const cartTotalLabel = document.getElementById('cart-total');
const checkoutButton = document.getElementById('checkout-button');
const easterEggTrigger = document.getElementById('easter-egg-trigger');
const easterEggModal = document.getElementById('easter-egg-modal');
const easterEggClose = document.getElementById('close-easter-egg');

let carritoPublico = [];  // [{ id, nombre, precio, cantidad, stockMax }]
let productosDisponibles = [];

// ─── UTILIDADES ──────────────────────────────────────────────────
function formatPrice(n) {
    return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n);
}

// ─── RENDER PRODUCTOS ─────────────────────────────────────────────
function renderizarProductos(lista) {
    if (!gridContainer) return;

    if (lista.length === 0) {
        gridContainer.innerHTML = '<p style="color:var(--text-muted); grid-column:1/-1;">No se encontraron productos.</p>';
        return;
    }

    gridContainer.innerHTML = lista.map(p => {
        const agotado = p.cant_exist === 0;
        return `
        <article class="product-card ${agotado ? 'agotado' : ''}">
            <div class="product-info">
                <h3>${p.nombre}</h3>
                <p class="product-description">${p.descripcion || 'Sin descripción.'}</p>
            </div>
            <div class="product-meta">
                <strong>${formatPrice(p.precio)}</strong>
                <span class="stock-badge ${agotado ? 'stock-cero' : p.cant_exist <= 5 ? 'stock-bajo' : ''}">
                    ${agotado ? 'Agotado' : `${p.cant_exist} disponibles`}
                </span>
            </div>
            <div class="product-footer">
                <button
                    class="btn-confirm"
                    onclick="addToCart('${p.id_producto}')"
                    ${agotado ? 'disabled' : ''}>
                    ${agotado ? 'Sin stock' : 'Agregar'}
                </button>
            </div>
        </article>`;
    }).join('');
}

// ─── CARRITO ──────────────────────────────────────────────────────
window.addToCart = function(id) {
    const producto = productosDisponibles.find(p => p.id_producto === id);
    if (!producto || producto.cant_exist === 0) return;

    const existente = carritoPublico.find(item => item.id === id);
    const cantidadActual = existente ? existente.cantidad : 0;

    // ✅ VALIDACIÓN: no permitir más que el stock disponible
    if (cantidadActual >= producto.cant_exist) {
        mostrarToast(`Solo hay ${producto.cant_exist} unidades de "${producto.nombre}"`, 'warn');
        return;
    }

    if (existente) {
        existente.cantidad += 1;
    } else {
        carritoPublico.push({
            id: producto.id_producto,
            nombre: producto.nombre,
            precio: Number(producto.precio),
            cantidad: 1,
            stockMax: producto.cant_exist
        });
    }

    actualizarCarrito();
    // Reflejar en grid que el stock "visual" baja
    actualizarStockVisual(id, -(1));
};

window.cambiarCantidadCarrito = function(id, delta) {
    const item = carritoPublico.find(i => i.id === id);
    if (!item) return;

    const nueva = item.cantidad + delta;

    if (nueva <= 0) {
        // Devolver al stock visual
        actualizarStockVisual(id, item.cantidad);
        carritoPublico = carritoPublico.filter(i => i.id !== id);
    } else if (nueva > item.stockMax) {
        mostrarToast(`Máximo ${item.stockMax} unidades disponibles`, 'warn');
        return;
    } else {
        actualizarStockVisual(id, -delta);
        item.cantidad = nueva;
    }

    actualizarCarrito();
};

function actualizarStockVisual(idProducto, delta) {
    // Actualiza el campo cant_exist local para que el UI refleje el stock restante
    const p = productosDisponibles.find(x => x.id_producto === idProducto);
    if (p) {
        p.cant_exist += delta;  // delta negativo = se reservó, positivo = se liberó
    }
}

function actualizarCarrito() {
    if (!cartItemsContainer || !cartTotalLabel) return;

    if (carritoPublico.length === 0) {
        cartItemsContainer.innerHTML = '<p class="empty-cart">Tu carrito está vacío.</p>';
        cartTotalLabel.textContent = formatPrice(0);
        if (checkoutButton) checkoutButton.disabled = true;
        return;
    }

    const itemsHtml = carritoPublico.map(item => `
        <div class="cart-item">
            <div>
                <strong>${item.nombre}</strong>
                <small>${formatPrice(item.precio)} c/u</small>
            </div>
            <div class="cart-item-controls">
                <button onclick="cambiarCantidadCarrito('${item.id}', -1)">−</button>
                <span>${item.cantidad}</span>
                <button onclick="cambiarCantidadCarrito('${item.id}', 1)">+</button>
                <span>${formatPrice(item.precio * item.cantidad)}</span>
            </div>
        </div>
    `).join('');

    const total = carritoPublico.reduce((s, i) => s + i.precio * i.cantidad, 0);
    cartItemsContainer.innerHTML = itemsHtml;
    cartTotalLabel.textContent = formatPrice(total);
    if (checkoutButton) checkoutButton.disabled = false;
}

// ─── CHECKOUT ────────────────────────────────────────────────────
async function finalizarCompra() {
    if (carritoPublico.length === 0) return;

    checkoutButton.disabled = true;
    checkoutButton.textContent = 'Procesando...';

    try {
        // 1. Descontar stock en Supabase con validación
        for (const item of carritoPublico) {
            const resultado = await descontarStock(item.id, item.cantidad);
            if (!resultado.ok) {
                const msg = resultado.disponible !== undefined
                    ? `Stock insuficiente para "${item.nombre}". Solo quedan ${resultado.disponible}.`
                    : `Error al actualizar "${item.nombre}": ${resultado.error}`;
                mostrarToast(msg, 'error');
                checkoutButton.disabled = false;
                checkoutButton.textContent = 'Finalizar Compra';
                return;
            }
        }

        // 2. Registrar venta
        const idVenta = 'V-' + Date.now();
        const total = carritoPublico.reduce((s, i) => s + i.precio * i.cantidad, 0);

        const { data: ventaGuardada, error: ventaError } = await registrarVenta({
            id_venta: idVenta,
            precio_total: total,
            curp_cliente: null,
            curp_trabajador: 'PUBL000000HDFPUB00',  // trabajador público placeholder
        });

        if (ventaError) {
            // Si la tabla ventas requiere FK válida, solo registramos el stock
            console.warn('Venta no registrada en BD (puede requerir curp_trabajador válido):', ventaError.message);
        }

        // 3. Registrar detalles
        const detalles = carritoPublico.map((item, idx) => ({
            id_venta: idVenta,
            id_detalle: idx + 1,
            cantidad: item.cantidad,
            precio_unitario: item.precio,
            subtotal: item.precio * item.cantidad,
            id_producto: item.id,
        }));
        await registrarDetallesVenta(detalles);

        mostrarToast('¡Compra realizada! Inventario actualizado.', 'ok');
        carritoPublico = [];
        await cargarProductos();
        actualizarCarrito();

    } catch (err) {
        mostrarToast('Error inesperado: ' + err.message, 'error');
        console.error(err);
        checkoutButton.disabled = false;
        checkoutButton.textContent = 'Finalizar Compra';
    }
}

// ─── CARGA Y BÚSQUEDA ────────────────────────────────────────────
async function cargarProductos() {
    gridContainer.innerHTML = '<p style="color:var(--text-muted); grid-column:1/-1;">Cargando productos...</p>';
    const { data, error } = await obtenerProductos();

    if (error || !data) {
        gridContainer.innerHTML = '<p style="color:var(--error); grid-column:1/-1;">Error al cargar productos. Revisa la conexión a Supabase.</p>';
        console.error(error);
        return;
    }

    productosDisponibles = data;
    renderizarProductos(productosDisponibles);
}

function filtrarProductos(termino) {
    const filtro = termino.toLowerCase();
    const filtrados = productosDisponibles.filter(p =>
        p.nombre.toLowerCase().includes(filtro) ||
        (p.descripcion || '').toLowerCase().includes(filtro)
    );
    renderizarProductos(filtrados);
}

// ─── TOAST ───────────────────────────────────────────────────────
function mostrarToast(mensaje, tipo = 'ok') {
    let toast = document.getElementById('toast-global');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast-global';
        document.body.appendChild(toast);
    }
    toast.textContent = mensaje;
    toast.className = `toast toast-${tipo} show`;
    setTimeout(() => toast.classList.remove('show'), 3500);
}

// ─── EASTER EGG ──────────────────────────────────────────────────
const easterKeywords = ['mortadela', 'sans', 'undertale'];

function checkEasterEgg(termino) {
    const found = easterKeywords.some(k => termino.toLowerCase().includes(k));
    if (easterEggTrigger) easterEggTrigger.classList.toggle('hidden', !found);
}

// ─── INIT ────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', async () => {
    await cargarProductos();
    actualizarCarrito();

    searchInput?.addEventListener('input', e => {
        filtrarProductos(e.target.value);
        checkEasterEgg(e.target.value);
    });

    easterEggTrigger?.addEventListener('click', () => easterEggModal?.classList.remove('hidden'));
    easterEggClose?.addEventListener('click', () => easterEggModal?.classList.add('hidden'));
    easterEggModal?.addEventListener('click', e => {
        if (e.target === easterEggModal) easterEggModal.classList.add('hidden');
    });

    checkoutButton?.addEventListener('click', finalizarCompra);
});
